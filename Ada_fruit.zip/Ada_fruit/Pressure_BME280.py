# | BME280 Pin | Raspberry Pi (BOARD) |
# | ---------- | -------------------- |
# | VCC        | Pin 1 (3.3V)         |
# | GND        | Pin 6 (GND)          |
# | SDA        | Pin 3 (GPIO2)        |
# | SCL        | Pin 5 (GPIO3)        |

# setup
# sudo raspi-config enable i2c
# pip install adafruit-circuitpython-bme280

import time
import board
import busio
import adafruit_bme280

# Create I2C bus
i2c = busio.I2C(board.SCL, board.SDA)

bme280 = adafruit_bme280.Adafruit_BME280_I2C(i2c)

bme280.sea_level_pressure = 1013.25

while True:
    temperature = bme280.temperature
    humidity = bme280.humidity
    pressure = bme280.pressure

    print(f"Temperature: {temperature:.2f} °C")
    print(f"Humidity: {humidity:.2f} %")
    print(f"Pressure: {pressure:.2f} hPa")
    print("----------------------------")

    time.sleep(2)



