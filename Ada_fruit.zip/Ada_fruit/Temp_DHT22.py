import time
import board
import adafruit_dht

# Use GPIO4 (D4)
dhtDevice = adafruit_dht.DHT22(board.D4)

while True:
    try:
        temperature = dhtDevice.temperature
        humidity = dhtDevice.humidity

        print(f"Temperature: {temperature:.1f} °C")
        print(f"Humidity: {humidity:.1f} %")
        print("------------------------")

    except RuntimeError as error:
        # Errors happen often, just retry
        print(error.args[0])

    except Exception as error:
        dhtDevice.exit()
        raise error

    time.sleep(2)


    
#     | Pin  | Function     |
# | ---- | ------------ |
# | VCC  | Power (3.3V) |
# | DATA | Signal       |
# | GND  | Ground       |
# | (NC) | Not used     |

# pip3 install Adafruit_DHT
# pip3 install adafruit-circuitpython-dht