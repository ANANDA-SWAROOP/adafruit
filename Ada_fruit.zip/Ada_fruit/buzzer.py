from gpiozero import LED, Buzzer
from time import sleep

# Define pins
led = LED(17)
buzzer = Buzzer(27)

while True:
    # Both ON
    led.on()
    buzzer.on()
    print("LED ON, Buzzer ON")
    sleep(2)

    # Both OFF
    led.off()
    buzzer.off()
    print("LED OFF, Buzzer OFF")
    sleep(2)