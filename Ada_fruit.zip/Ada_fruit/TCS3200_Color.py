# | TCS3200 | Raspberry Pi (BOARD) |
# | ------- | -------------------- |
# | VCC     | Pin 1 (3.3V)         |
# | GND     | Pin 6 (GND)          |
# | S0      | Pin 16               |
# | S1      | Pin 18               |
# | S2      | Pin 22               |
# | S3      | Pin 24               |
# | OUT     | Pin 26               |
# | OE      | GND (always enabled) |

import RPi.GPIO as GPIO
import time

# Pin setup
S2 = 27
S3 = 22
OUT = 17
S0 = 23
S1 = 24

GPIO.setmode(GPIO.BCM)

GPIO.setup(S2, GPIO.OUT)
GPIO.setup(S3, GPIO.OUT)
GPIO.setup(S0, GPIO.OUT)
GPIO.setup(S1, GPIO.OUT)
GPIO.setup(OUT, GPIO.IN)

# Set frequency scaling to 20%
GPIO.output(S0, GPIO.HIGH)
GPIO.output(S1, GPIO.LOW)

def read_color(s2, s3):
    GPIO.output(S2, s2)
    GPIO.output(S3, s3)
    time.sleep(0.1)

    start = time.time()
    for _ in range(100):
        GPIO.wait_for_edge(OUT, GPIO.FALLING)
    duration = time.time() - start

    return duration

try:
    while True:
        red = read_color(GPIO.LOW, GPIO.LOW)
        blue = read_color(GPIO.LOW, GPIO.HIGH)
        green = read_color(GPIO.HIGH, GPIO.HIGH)

        print("Red:", red)
        print("Green:", green)
        print("Blue:", blue)
        print("----------------------")

        time.sleep(1)

except KeyboardInterrupt:
    GPIO.cleanup()