#!/usr/bin/env python3

from pyfingerprint.pyfingerprint import PyFingerprint
import time

try:
    # Initialize sensor
    f = PyFingerprint('/dev/serial0', 57600, 0xFFFFFFFF, 0x00000000)

    if not f.verifyPassword():
        raise ValueError('Wrong fingerprint sensor password')

    print('Sensor initialized')
    print('Currently stored templates:', f.getTemplateCount())
    print('Storage capacity:', f.getStorageCapacity())

except Exception as e:
    print('Error initializing sensor:', e)
    exit(1)


# ---------------- ENROLL FUNCTION ----------------
def enroll_finger():
    try:
        print('Place finger...')

        while not f.readImage():
            pass

        f.convertImage(0x01)

        positionNumber = f.searchTemplate()[0]

        if positionNumber >= 0:
            print('Finger already exists at position:', positionNumber)
            return

        print('Remove finger...')
        time.sleep(2)

        print('Place same finger again...')

        while not f.readImage():
            pass

        f.convertImage(0x02)

        if f.compareCharacteristics() == 0:
            raise Exception('Fingerprints do not match')

        f.createTemplate()

        positionNumber = f.storeTemplate()
        print('Finger enrolled successfully at position:', positionNumber)

    except Exception as e:
        print('Enrollment failed:', e)


# ---------------- SEARCH FUNCTION ----------------
def search_finger():
    try:
        print('Waiting for finger...')

        while not f.readImage():
            pass

        f.convertImage(0x01)

        result = f.searchTemplate()

        positionNumber = result[0]
        accuracyScore = result[1]

        if positionNumber == -1:
            print('No match found')
        else:
            print('Match found at position:', positionNumber)
            print('Accuracy score:', accuracyScore)

    except Exception as e:
        print('Search failed:', e)


# ---------------- MAIN MENU ----------------
while True:
    print('\n1. Enroll Finger')
    print('2. Search Finger')
    print('3. Exit')

    choice = input('Enter choice: ')

    if choice == '1':
        enroll_finger()
    elif choice == '2':
        search_finger()
    elif choice == '3':
        break
    else:
        print('Invalid choice')



# sudo raspi-config
# Interface Options → Serial Port
# Disable login shell over serial → No
# Enable serial port hardware → Yes
# sudo reboot
# pip3 install pyfingerprint

# | R305 Pin | Pi Pin               |
# | -------- | -------------------- |
# | VCC      | 5V (Pin 2)           |
# | GND      | GND (Pin 6)          |
# | TX       | GPIO15 (RXD, Pin 10) |
# | RX       | GPIO14 (TXD, Pin 8)  |
