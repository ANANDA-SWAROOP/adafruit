# | LCD Pin  | Connect to               |
# | -------- | ------------------------ |
# | VSS      | GND                      |
# | VDD      | 5V                       |
# | V0       | Potentiometer (contrast) |
# | RS       | GPIO 26                  |
# | EN       | GPIO 19                  |
# | D4       | GPIO 13                  |
# | D5       | GPIO 6                   |
# | D6       | GPIO 5                   |
# | D7       | GPIO 11                  |
# | A (LED+) | 5V (via resistor)        |
# | K (LED-) | GND                      |

# install
# pip install Adafruit_CharLCD


import time
import Adafruit_CharLCD as LCD

lcd_rs = 26
lcd_en = 19
lcd_d4 = 13
lcd_d5 = 6
lcd_d6 = 5
lcd_d7 = 11
lcd_backlight = 2
lcd_columns = 16
lcd_rows = 2

lcd = LCD.Adafruit_CharLCD(
    lcd_rs, lcd_en,
    lcd_d4, lcd_d5, lcd_d6, lcd_d7,
    lcd_columns, lcd_rows, lcd_backlight
)

lcd.message('NIT TRICHY CSE')
time.sleep(3.0)
lcd.clear()

text = input("type:")

lcd.message(text)
time.sleep(3.0)
lcd.clear()

lcd.message('good bye')
time.sleep(3.0)
lcd.clear()

print("exit")

