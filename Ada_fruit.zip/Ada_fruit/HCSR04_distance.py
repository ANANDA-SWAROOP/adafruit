import RPi.GPIO as GPIO
import time

# Set GPIO mode to BCM (Broadcom SoC specific numbers)
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

# Pin Definitions
TRIG_PIN = 23
ECHO_PIN = 24

# Setup GPIO pins
GPIO.setup(TRIG_PIN, GPIO.OUT)
GPIO.setup(ECHO_PIN, GPIO.IN)

def measure_distance():
    # Ensure the trigger pin is low
    GPIO.output(TRIG_PIN, False)
    time.sleep(0.1)  # Allow sensor to settle

    # Send a 10us pulse to TRIG
    GPIO.output(TRIG_PIN, True)
    time.sleep(0.00001)
    GPIO.output(TRIG_PIN, False)

    # Wait for ECHO to go high (start of pulse)
    start_time = time.time()
    timeout = time.time() + 0.1  # 100ms timeout to prevent hanging
    while GPIO.input(ECHO_PIN) == 0:
        start_time = time.time()
        if time.time() > timeout:
            return None # Timeout error

    # Wait for ECHO to go low (end of pulse)
    stop_time = time.time()
    timeout = time.time() + 0.1
    while GPIO.input(ECHO_PIN) == 1:
        stop_time = time.time()
        if time.time() > timeout:
            return None # Timeout error

    # Calculate pulse duration
    pulse_duration = stop_time - start_time

    # Calculate distance
    # Speed of sound = 34300 cm/s
    # Distance = (Duration * Speed) / 2 (because sound travels back and forth)
    distance = (pulse_duration * 34300) / 2

    return distance

try:
    print("Starting Distance Measurement (Ctrl+C to stop)")
    while True:
        dist = measure_distance()
        
        if dist is not None:
            # Round to 2 decimal places
            dist = round(dist, 2)
            print(f"Distance: {dist} cm")
        else:
            print("Measurement Timeout")
            
        time.sleep(0.5) # Wait half a second before next reading

except KeyboardInterrupt:
    print("\nMeasurement stopped by user")

finally:
    # Clean up GPIO pins on exit
    GPIO.cleanup()
    
    
    
    
# circuit -> echo pin via resistor
# | HC-SR04 | Raspberry Pi                     |
# | ------- | -------------------------------- |
# | VCC     | 5V (Pin 2)                       |
# | GND     | GND (Pin 6)                      |
# | TRIG    | GPIO 23                          |
# | ECHO    | GPIO 24 (via voltage divider ⚠️) |
