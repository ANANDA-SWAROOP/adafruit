from gpiozero import DistanceSensor
from time import sleep

# Define GPIO pins (BCM numbering)
TRIG_PIN = 23
ECHO_PIN = 24

# Initialize the sensor
# queue_len=5 averages the last 5 readings for stability
# max_distance=2.0 sets the limit to 2 meters (adjust based on your needs)
sensor = DistanceSensor(echo=ECHO_PIN, trigger=TRIG_PIN, queue_len=5, max_distance=2.0)

try:
    print("Starting Distance Measurement (Ctrl+C to exit)")
    
    while True:
        # .distance returns value in meters
        distance_meters = sensor.distance
        
        # Convert to centimeters
        distance_cm = distance_meters * 100
        
        # Print formatted output
        print(f"Distance: {distance_cm:.2f} cm")
        
        sleep(0.5)

except KeyboardInterrupt:
    print("\nMeasurement stopped by user")

finally:
    # gpiozero handles cleanup automatically, but good practice to close
    sensor.close()