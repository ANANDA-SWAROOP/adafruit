import RPi.GPIO as GPIO
import time

# Set GPIO mode to BCM
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

# Pin Definitions
PIR_PIN = 17  # Connected to OUT pin of HC-SR501

# Setup GPIO pin
GPIO.setup(PIR_PIN, GPIO.IN)

def motion_detected(channel):
    print(f"⚠️  MOTION DETECTED at {time.strftime('%H:%M:%S')}!")
    
    
def main():
    print("Initializing PIR Sensor...")
    print("Waiting for sensor to stabilize (approx 60 seconds)...")
    
    time.sleep(60) 
    
    print("Sensor is now ready! Monitoring for motion...")
    
    GPIO.add_event_detect(PIR_PIN, GPIO.RISING, callback=motion_detected, bouncetime=2000)

    try:
        while True:
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\nMonitoring stopped by user.")
    
    finally:
        GPIO.cleanup()

if __name__ == "__main__":
    main()
    
    
# basic circuit