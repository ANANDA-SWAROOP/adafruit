import RPi.GPIO as GPIO
import time

MQ3_PIN = 17  # GPIO17

GPIO.setmode(GPIO.BCM)
GPIO.setup(MQ3_PIN, GPIO.IN)

try:
    while True:
        sensor_value = GPIO.input(MQ3_PIN)

        if sensor_value == 0:
            print("Alcohol Detected!")
        else:
            print("No Alcohol")

        time.sleep(1)

except KeyboardInterrupt:
    GPIO.cleanup()
    
# circuit
# | MQ-3 Pin | Raspberry Pi 4  |
# | -------- | --------------- |
# | VCC      | 5V (Pin 2)      |
# | GND      | GND (Pin 6)     |
# | DO       | GPIO17 (Pin 11) |
